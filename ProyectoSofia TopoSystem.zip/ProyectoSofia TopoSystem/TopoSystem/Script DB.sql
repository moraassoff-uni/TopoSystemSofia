-- Create the database
CREATE DATABASE ToposystemDB;
GO

USE ToposystemDB;
GO

-- Users Table
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FirstName NVARCHAR(100) NOT NULL, 
    LastName NVARCHAR(100) NOT NULL, 
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(255) NOT NULL,
    UserRole NVARCHAR(50) CHECK (UserRole IN ('Administrator', 'Employee', 'Client')), 
    Phone NVARCHAR(15), 
    Address NVARCHAR(255), 
    CreatedAt DATETIME DEFAULT GETDATE(), 
    UpdatedAt DATETIME NULL, 
    LastLogin DATETIME NULL 
);

-- Projects Table
CREATE TABLE Projects (
    ProjectID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    Type NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX),
    Phase NVARCHAR(50) CHECK (Phase IN ('Created', 'In Progress', 'Completed', 'Cancelled')),
    Budget DECIMAL(18,2),
    Location NVARCHAR(100) NOT NULL,
    StartDate DATE,
    EndDate DATE,
    
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Suppliers Table
CREATE TABLE Suppliers (
    SupplierID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    ContactInfo NVARCHAR(MAX),
    Address NVARCHAR(255)
);

-- Inventory Table
CREATE TABLE Inventory (
    MaterialID INT PRIMARY KEY IDENTITY(1,1),
    SupplierID INT,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX),
    Quantity INT,
    Price DECIMAL(18,2),

    FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID)
);

-- ProjectMaterials Table
CREATE TABLE ProjectMaterials (
    ID INT PRIMARY KEY IDENTITY(1,1),
    ProjectID INT NOT NULL,
    MaterialID INT NOT NULL,
    Quantity INT NOT NULL,

    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    FOREIGN KEY (MaterialID) REFERENCES Inventory(MaterialID)
);


-- Incidents Table
CREATE TABLE Incidents (
    IncidentID INT PRIMARY KEY IDENTITY(1,1),
    ProjectID INT NOT NULL,
    UserID INT NOT NULL,
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(MAX),
    Priority NVARCHAR(50) CHECK (Priority IN ('High', 'Medium', 'Low')),
    Phase NVARCHAR(50) CHECK (Phase IN ('To Do', 'In Progress', 'Completed')),
    StartDate DATE DEFAULT GETDATE(),
    Justification NVARCHAR(100) NOT NULL,

    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Vacations Table
CREATE TABLE Vacations (
    VacationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT NOT NULL,
    StartDate DATE,
    EndDate DATE,
    Status NVARCHAR(50) CHECK (Status IN ('Pending', 'Approved', 'Rejected')),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Attendance Table
CREATE TABLE Attendance (
    AttendanceID INT PRIMARY KEY IDENTITY(1,1), 
    UserID INT NOT NULL, 
    Date DATE NOT NULL,
    EntryTime TIME, 
    ExitTime TIME,
    IsPresent BIT NOT NULL DEFAULT 1, 
    IsVacation BIT NOT NULL DEFAULT 0, 
    OvertimeHours INT DEFAULT 0, 

    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- Finances Table
CREATE TABLE Finances (
    FinanceID INT PRIMARY KEY IDENTITY(1,1),
    ProjectID INT NOT NULL,
    Type NVARCHAR(50) CHECK (Type IN ('Income', 'Expense','Budget')),
    Amount DECIMAL(18,2),
    TransactionDate DATE,
    Description NVARCHAR(MAX),
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID)
);

-- Reports Table
CREATE TABLE ReportTypes (
    ReportTypeID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL
);

-- Reports Table
CREATE TABLE Reports (
    ReportID INT PRIMARY KEY IDENTITY(1,1),
    ProjectID INT NOT NULL,
    ReportTypeID INT NOT NULL,
    GeneratedBy INT NOT NULL,  -- User who generated the report
    CreatedAt DATETIME DEFAULT GETDATE(),

    -- Para jalar la tabla de finanzas
    FinanceID INT NULL,

    -- tomar referencias ese empleados
    AttendanceID INT NULL,
    VacationID INT NULL,

    -- consolidado de todos los projectos completados
    CompletedProjectID INT NULL, 

    -- jala los materiales presentes en la tabla
    MaterialID INT NULL,

    
    FOREIGN KEY (ProjectID) REFERENCES Projects(ProjectID),
    FOREIGN KEY (ReportTypeID) REFERENCES ReportTypes(ReportTypeID),
    FOREIGN KEY (GeneratedBy) REFERENCES Users(UserID),
    
   
    FOREIGN KEY (FinanceID) REFERENCES Finances(FinanceID),

 
    FOREIGN KEY (AttendanceID) REFERENCES Attendance(AttendanceID),
    FOREIGN KEY (VacationID) REFERENCES Vacations(VacationID),

    
    FOREIGN KEY (CompletedProjectID) REFERENCES Projects(ProjectID),

    
    FOREIGN KEY (MaterialID) REFERENCES Inventory(MaterialID)
);





-- Indexes and Query Optimization
CREATE INDEX IDX_Projects_UserID ON Projects(UserID);
CREATE INDEX IDX_ProjectMaterials_ProjectID ON ProjectMaterials(ProjectID);
CREATE INDEX IDX_ProjectMaterials_MaterialID ON ProjectMaterials(MaterialID);
CREATE INDEX IDX_Inventory_SupplierID ON Inventory(SupplierID);
CREATE INDEX IDX_Incidents_ProjectID ON Incidents(ProjectID);
CREATE INDEX IDX_Incidents_UserID ON Incidents(UserID);
CREATE INDEX IDX_Vacations_UserID ON Vacations(UserID);
CREATE INDEX IDX_Attendance_UserID ON Attendance(UserID);
CREATE INDEX IDX_Finances_ProjectID ON Finances(ProjectID);
CREATE INDEX IDX_Reports_ProjectID ON Reports(ProjectID);
CREATE INDEX IDX_Reports_ReportTypeID ON Reports(ReportTypeID);


ALTER TABLE Users
ADD IsActive BIT NOT NULL DEFAULT 1;
