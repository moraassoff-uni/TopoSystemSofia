﻿namespace TopoSystem.Data
{
    public class Class1
    {

    }
}
