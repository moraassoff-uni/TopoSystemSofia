﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Attendance
{
    public int AttendanceId { get; set; }

    public int UserId { get; set; }

    public DateOnly Date { get; set; }

    public TimeOnly? EntryTime { get; set; }

    public TimeOnly? ExitTime { get; set; }

    public bool IsPresent { get; set; }

    public bool IsVacation { get; set; }

    public int? OvertimeHours { get; set; }

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();

    public virtual User User { get; set; } = null!;
}
