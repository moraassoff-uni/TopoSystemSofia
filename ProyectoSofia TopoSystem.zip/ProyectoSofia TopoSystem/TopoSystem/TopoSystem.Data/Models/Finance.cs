﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Finance
{
    public int FinanceId { get; set; }

    public int ProjectId { get; set; }

    public string? Type { get; set; }

    public decimal? Amount { get; set; }

    public DateOnly? TransactionDate { get; set; }

    public string? Description { get; set; }

    public virtual Project Project { get; set; } = null!;

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();
}
