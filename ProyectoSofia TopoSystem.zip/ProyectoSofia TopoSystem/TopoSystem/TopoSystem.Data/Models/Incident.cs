﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Incident
{
    public int IncidentId { get; set; }

    public int ProjectId { get; set; }

    public int UserId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string? Priority { get; set; }

    public string? Phase { get; set; }

    public DateOnly? StartDate { get; set; }

    public string Justification { get; set; } = null!;

    public virtual Project Project { get; set; } = null!;

    public virtual User User { get; set; } = null!;
}
