﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Inventory
{
    public int MaterialId { get; set; }

    public int? SupplierId { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public int? Quantity { get; set; }

    public decimal? Price { get; set; }

    public virtual ICollection<ProjectMaterial> ProjectMaterials { get; set; } = new List<ProjectMaterial>();

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();

    public virtual Supplier? Supplier { get; set; }
}
