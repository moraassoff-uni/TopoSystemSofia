﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Project
{
    public int ProjectId { get; set; }

    public int UserId { get; set; }

    public string Name { get; set; } = null!;

    public string Type { get; set; } = null!;

    public string? Description { get; set; }

    public string? Phase { get; set; }

    public decimal? Budget { get; set; }

    public string Location { get; set; } = null!;

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public virtual ICollection<Finance> Finances { get; set; } = new List<Finance>();

    public virtual ICollection<Incident> Incidents { get; set; } = new List<Incident>();

    public virtual ICollection<ProjectMaterial> ProjectMaterials { get; set; } = new List<ProjectMaterial>();

    public virtual ICollection<Report> ReportCompletedProjects { get; set; } = new List<Report>();

    public virtual ICollection<Report> ReportProjects { get; set; } = new List<Report>();

    public virtual User User { get; set; } = null!;
}
