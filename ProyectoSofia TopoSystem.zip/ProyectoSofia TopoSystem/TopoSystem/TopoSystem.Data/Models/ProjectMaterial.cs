﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class ProjectMaterial
{
    public int Id { get; set; }

    public int ProjectId { get; set; }

    public int MaterialId { get; set; }

    public int Quantity { get; set; }

    public virtual Inventory Material { get; set; } = null!;

    public virtual Project Project { get; set; } = null!;
}
