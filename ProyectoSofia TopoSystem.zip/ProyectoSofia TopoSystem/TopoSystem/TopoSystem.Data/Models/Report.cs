﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Report
{
    public int ReportId { get; set; }

    public int ProjectId { get; set; }

    public int ReportTypeId { get; set; }

    public int GeneratedBy { get; set; }

    public DateTime? CreatedAt { get; set; }

    public int? FinanceId { get; set; }

    public int? AttendanceId { get; set; }

    public int? VacationId { get; set; }

    public int? CompletedProjectId { get; set; }

    public int? MaterialId { get; set; }

    public virtual Attendance? Attendance { get; set; }

    public virtual Project? CompletedProject { get; set; }

    public virtual Finance? Finance { get; set; }

    public virtual User GeneratedByNavigation { get; set; } = null!;

    public virtual Inventory? Material { get; set; }

    public virtual Project Project { get; set; } = null!;

    public virtual ReportType ReportType { get; set; } = null!;

    public virtual Vacation? Vacation { get; set; }
}
