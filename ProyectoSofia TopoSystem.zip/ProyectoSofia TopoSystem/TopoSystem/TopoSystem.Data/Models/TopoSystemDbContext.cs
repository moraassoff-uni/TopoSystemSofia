﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TopoSystem.Data.Models;

public partial class TopoSystemDbContext : DbContext
{
    public TopoSystemDbContext()
    {
    }

    public TopoSystemDbContext(DbContextOptions<TopoSystemDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Attendance> Attendances { get; set; }

    public virtual DbSet<Finance> Finances { get; set; }

    public virtual DbSet<Incident> Incidents { get; set; }

    public virtual DbSet<Inventory> Inventories { get; set; }

    public virtual DbSet<Project> Projects { get; set; }

    public virtual DbSet<ProjectMaterial> ProjectMaterials { get; set; }

    public virtual DbSet<Report> Reports { get; set; }

    public virtual DbSet<ReportType> ReportTypes { get; set; }

    public virtual DbSet<Supplier> Suppliers { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<Vacation> Vacations { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=LAPTOP-22US8U5E\\SQLEXPRESS;Database=TopoSystemDB;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Attendance>(entity =>
        {
            entity.HasKey(e => e.AttendanceId).HasName("PK__Attendan__8B69263CBEACB0FF");

            entity.ToTable("Attendance");

            entity.HasIndex(e => e.UserId, "IDX_Attendance_UserID");

            entity.Property(e => e.AttendanceId).HasColumnName("AttendanceID");
            entity.Property(e => e.IsPresent).HasDefaultValue(true);
            entity.Property(e => e.OvertimeHours).HasDefaultValue(0);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.Attendances)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Attendanc__UserI__5629CD9C");
        });

        modelBuilder.Entity<Finance>(entity =>
        {
            entity.HasKey(e => e.FinanceId).HasName("PK__Finances__7917A8FFA2D95A9E");

            entity.HasIndex(e => e.ProjectId, "IDX_Finances_ProjectID");

            entity.Property(e => e.FinanceId).HasColumnName("FinanceID");
            entity.Property(e => e.Amount).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.Type).HasMaxLength(50);

            entity.HasOne(d => d.Project).WithMany(p => p.Finances)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Finances__Projec__59FA5E80");
        });

        modelBuilder.Entity<Incident>(entity =>
        {
            entity.HasKey(e => e.IncidentId).HasName("PK__Incident__3D8053925177789F");

            entity.HasIndex(e => e.ProjectId, "IDX_Incidents_ProjectID");

            entity.HasIndex(e => e.UserId, "IDX_Incidents_UserID");

            entity.Property(e => e.IncidentId).HasColumnName("IncidentID");
            entity.Property(e => e.Justification).HasMaxLength(100);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Phase).HasMaxLength(50);
            entity.Property(e => e.Priority).HasMaxLength(50);
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.StartDate).HasDefaultValueSql("(getdate())");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Project).WithMany(p => p.Incidents)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Incidents__Proje__4BAC3F29");

            entity.HasOne(d => d.User).WithMany(p => p.Incidents)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Incidents__UserI__4CA06362");
        });

        modelBuilder.Entity<Inventory>(entity =>
        {
            entity.HasKey(e => e.MaterialId).HasName("PK__Inventor__C5061317CB934B16");

            entity.ToTable("Inventory");

            entity.HasIndex(e => e.SupplierId, "IDX_Inventory_SupplierID");

            entity.Property(e => e.MaterialId).HasColumnName("MaterialID");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Price).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

            entity.HasOne(d => d.Supplier).WithMany(p => p.Inventories)
                .HasForeignKey(d => d.SupplierId)
                .HasConstraintName("FK__Inventory__Suppl__4222D4EF");
        });

        modelBuilder.Entity<Project>(entity =>
        {
            entity.HasKey(e => e.ProjectId).HasName("PK__Projects__761ABED0D5A18267");

            entity.HasIndex(e => e.UserId, "IDX_Projects_UserID");

            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.Budget).HasColumnType("decimal(18, 2)");
            entity.Property(e => e.Location).HasMaxLength(100);
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Phase).HasMaxLength(50);
            entity.Property(e => e.Type).HasMaxLength(100);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.Projects)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Projects__UserID__3D5E1FD2");
        });

        modelBuilder.Entity<ProjectMaterial>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__ProjectM__3214EC27B35A4D8A");

            entity.HasIndex(e => e.MaterialId, "IDX_ProjectMaterials_MaterialID");

            entity.HasIndex(e => e.ProjectId, "IDX_ProjectMaterials_ProjectID");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.MaterialId).HasColumnName("MaterialID");
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");

            entity.HasOne(d => d.Material).WithMany(p => p.ProjectMaterials)
                .HasForeignKey(d => d.MaterialId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ProjectMa__Mater__45F365D3");

            entity.HasOne(d => d.Project).WithMany(p => p.ProjectMaterials)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ProjectMa__Proje__44FF419A");
        });

        modelBuilder.Entity<Report>(entity =>
        {
            entity.HasKey(e => e.ReportId).HasName("PK__Reports__D5BD48E57D31F7FD");

            entity.HasIndex(e => e.ProjectId, "IDX_Reports_ProjectID");

            entity.HasIndex(e => e.ReportTypeId, "IDX_Reports_ReportTypeID");

            entity.Property(e => e.ReportId).HasColumnName("ReportID");
            entity.Property(e => e.AttendanceId).HasColumnName("AttendanceID");
            entity.Property(e => e.CompletedProjectId).HasColumnName("CompletedProjectID");
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.FinanceId).HasColumnName("FinanceID");
            entity.Property(e => e.MaterialId).HasColumnName("MaterialID");
            entity.Property(e => e.ProjectId).HasColumnName("ProjectID");
            entity.Property(e => e.ReportTypeId).HasColumnName("ReportTypeID");
            entity.Property(e => e.VacationId).HasColumnName("VacationID");

            entity.HasOne(d => d.Attendance).WithMany(p => p.Reports)
                .HasForeignKey(d => d.AttendanceId)
                .HasConstraintName("FK__Reports__Attenda__6383C8BA");

            entity.HasOne(d => d.CompletedProject).WithMany(p => p.ReportCompletedProjects)
                .HasForeignKey(d => d.CompletedProjectId)
                .HasConstraintName("FK__Reports__Complet__656C112C");

            entity.HasOne(d => d.Finance).WithMany(p => p.Reports)
                .HasForeignKey(d => d.FinanceId)
                .HasConstraintName("FK__Reports__Finance__628FA481");

            entity.HasOne(d => d.GeneratedByNavigation).WithMany(p => p.Reports)
                .HasForeignKey(d => d.GeneratedBy)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reports__Generat__619B8048");

            entity.HasOne(d => d.Material).WithMany(p => p.Reports)
                .HasForeignKey(d => d.MaterialId)
                .HasConstraintName("FK__Reports__Materia__66603565");

            entity.HasOne(d => d.Project).WithMany(p => p.ReportProjects)
                .HasForeignKey(d => d.ProjectId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reports__Project__5FB337D6");

            entity.HasOne(d => d.ReportType).WithMany(p => p.Reports)
                .HasForeignKey(d => d.ReportTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Reports__ReportT__60A75C0F");

            entity.HasOne(d => d.Vacation).WithMany(p => p.Reports)
                .HasForeignKey(d => d.VacationId)
                .HasConstraintName("FK__Reports__Vacatio__6477ECF3");
        });

        modelBuilder.Entity<ReportType>(entity =>
        {
            entity.HasKey(e => e.ReportTypeId).HasName("PK__ReportTy__78CF8C83817462E1");

            entity.Property(e => e.ReportTypeId).HasColumnName("ReportTypeID");
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<Supplier>(entity =>
        {
            entity.HasKey(e => e.SupplierId).HasName("PK__Supplier__4BE66694716E0957");

            entity.Property(e => e.SupplierId).HasColumnName("SupplierID");
            entity.Property(e => e.Address).HasMaxLength(255);
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__Users__1788CCAC98DD6C66");

            entity.HasIndex(e => e.Email, "UQ__Users__A9D1053493F0C8CC").IsUnique();

            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Address).HasMaxLength(255);
            entity.Property(e => e.CreatedAt)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");
            entity.Property(e => e.Email).HasMaxLength(100);
            entity.Property(e => e.FirstName).HasMaxLength(100);
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.LastLogin).HasColumnType("datetime");
            entity.Property(e => e.LastName).HasMaxLength(100);
            entity.Property(e => e.Password).HasMaxLength(255);
            entity.Property(e => e.Phone).HasMaxLength(15);
            entity.Property(e => e.UpdatedAt).HasColumnType("datetime");
            entity.Property(e => e.UserRole).HasMaxLength(50);
        });

        modelBuilder.Entity<Vacation>(entity =>
        {
            entity.HasKey(e => e.VacationId).HasName("PK__Vacation__E420DF84020A566A");

            entity.HasIndex(e => e.UserId, "IDX_Vacations_UserID");

            entity.Property(e => e.VacationId).HasColumnName("VacationID");
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User).WithMany(p => p.Vacations)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Vacations__UserI__5070F446");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
