﻿using System;
using System.Collections.Generic;

namespace TopoSystem.Data.Models;

public partial class Vacation
{
    public int VacationId { get; set; }

    public int UserId { get; set; }

    public DateOnly? StartDate { get; set; }

    public DateOnly? EndDate { get; set; }

    public string? Status { get; set; }

    public virtual ICollection<Report> Reports { get; set; } = new List<Report>();

    public virtual User User { get; set; } = null!;
}
