﻿using Microsoft.AspNetCore.Mvc;
using TopoSystem.Models;
using TopoSystem.Data.Models;

namespace TopoSystem.Controllers
{
    public class AccountController : Controller
    {
        private readonly TopoSystemDbContext _context = new TopoSystemDbContext();
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.ErrorMessage = "Ingrese credenciales válidas.";
                return View();
            }

            var user = _context.Users.FirstOrDefault(u => u.Email == model.Email && u.Password == model.Password);

            if (user != null)
            {
                HttpContext.Session.SetString("AuthenticatedUser", user.Email);
                HttpContext.Session.SetString("UserRole", user.UserRole);
                return RedirectToAction("Index", "Home");
            }

            ViewBag.ErrorMessage = "Credenciales incorrectas. Intenta de nuevo.";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); // Limpiar sesión
            return RedirectToAction("Login");
        }
    }
}
