﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TopoSystem.Data.Models;
using TopoSystem.Models;
using System.Linq;
using System.Threading.Tasks;
using TopoSystem.Helpers;


namespace TopoSystem.Controllers
{
    public class AdministrationController : Controller
    {
        private readonly TopoSystemDbContext _context = new TopoSystemDbContext();
        // Muestra la lista de usuarios
        public async Task<IActionResult> AdministrationMenu()
        {
            var users = await _context.Users.ToListAsync();
            ViewBag.SuccessMessage = TempData["SuccessMessage"];
            ViewBag.ErrorMessage = TempData["ErrorMessage"];
            return View(users);
        }

        // Vista para crear usuario
        public IActionResult CreateUser()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser(UserModel user)
        {
            if (!ModelState.IsValid)
            {
                return View(user);
            }

            // Validar si el correo ya existe en la base de datos
            if (await _context.Users.AnyAsync(u => u.Email == user.Email))
            {
                ModelState.AddModelError("Email", "Este correo ya está registrado.");
                return View(user);
            }

            // Convertir UserModel a User (si existe una entidad User en la base de datos)
            var newUser = new User
            {
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                Password = SecurityHelper.HashPassword(user.Password), // Aplicar hash SHA256
                UserRole = user.UserRole,
                Phone = user.Phone,
                Address = user.Address,
                CreatedAt = DateTime.Now,
                IsActive = true
            };

            _context.Users.Add(newUser);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Usuario creado exitosamente.";
            return RedirectToAction("AdministrationMenu");
        }


        // Vista para cambiar contraseña
        /*public IActionResult ChangePassword(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                TempData["ErrorMessage"] = "Usuario no encontrado.";
                return RedirectToAction("AdministrationMenu");
            }
            return View(new ChangePasswordModel { UserId = id });
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await _context.Users.FindAsync(model.UserId);
            if (user == null)
            {
                TempData["ErrorMessage"] = "Usuario no encontrado.";
                return RedirectToAction("AdministrationMenu");
            }

            if (!IsPasswordSecure(model.NewPassword))
            {
                ModelState.AddModelError("NewPassword", "La contraseña no cumple con los requisitos de seguridad.");
                return View(model);
            }

            user.Password = BCrypt.Net.BCrypt.HashPassword(model.NewPassword);
            user.UpdatedAt = DateTime.Now;

            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Contraseña actualizada exitosamente.";
            return RedirectToAction("ChangePassword", new { id = model.UserId });
        }

        private bool IsPasswordSecure(string password)
        {
            return password.Length >= 8 &&
                   password.Any(char.IsUpper) &&
                   password.Any(char.IsDigit) &&
                   password.Any(ch => "!@#$%^&*()".Contains(ch));
        }*/
    }
}